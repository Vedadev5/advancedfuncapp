
// This file can be nearly empty when using pluginManagement in settings.gradle.kts
